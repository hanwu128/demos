<template>
    <div>
        <div class="page_title_content">
          <span class="page_title">边缘分析&nbsp;&gt;&nbsp;<router-link to="/edge/manager" class="btn_color">网关设备管理</router-link>&nbsp;&gt;&nbsp;网关设备详情</span>
        </div>
        <div class="right_content">
            <!--网关设备信息-->
            <div class="gateWay">
                <span class="module_title">网关设备信息</span>
                <span class="btn_save gateWayKey" @click="gateway_show()">&nbsp;网关秘钥&nbsp;</span>
            </div>
            <table class="gateWayInfoTable">
                <tr>
                    <td class='table_th' style='width:20%'>网关设备接入名称</td>
                    <td style='width:30%'>{{this.deviceDetail.access_key}}</td>
                    <td class='table_th' style='width:20%'>网关设备ID</td>
                    <td style='width:30%'>{{this.deviceDetail.device_id}}</td>
                </tr>
                <tr>
                    <td class='table_th'>网关设备型号</td>
                    <td>{{this.deviceDetail.meta.hardware_model}}</td>
                    <td class='table_th'>位置</td>
                    <td>{{this.deviceDetail.meta.hardware_location}}</td>
                </tr>
                <tr>
                    <td class='table_th'>操作系统</td>
                    <td>{{this.deviceDetail.meta.hardware_os}}</td>
                    <td class='table_th'>操作系统版本</td>
                    <td>{{this.deviceDetail.meta.hardware_os_version}}</td>
                </tr>
                <tr>
                    <td class='table_th'>固件版本</td>
                    <td>{{this.deviceDetail.meta.hardwareosversion}}</td>
                    <td class='table_th'>厂商</td>
                    <td>{{this.deviceDetail.meta.hardwaremanufactor}}</td>
                </tr>
            </table>
            <!--网关设备描述-->
            <div class="gateWay">
                <span class="module_title">网关设备描述</span>
                <p class="gateWayDes">
                    {{this.deviceDetail.device_desc}}
                </p>
            </div>
            <!--Agent信息-->
            <div class="gateWay">
                <span class="module_title">Agent信息</span>
            </div>
            <table class="gateWayInfoTable">
                <tr>
                    <td class='table_th' style='width:20%'>Agent名称</td>
                    <td style='width:30%'>{{this.deviceDetail.meta.edgent_agent_name}}</td>
                    <td class='table_th' style='width:20%'>Agent版本</td>
                    <td style='width:30%'>{{this.deviceDetail.meta.edgent_agent_version}}</td>
                </tr>
            </table>
            <!--Agent描述-->
            <!--
            <div class="gateWay">
                <span class="module_title">Agent描述</span>
                <p class="gateWayDes">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis
                </p>
            </div>
            -->
            <!--处理模块信息-->
            <div class="gateWay">
                <span class="module_title">处理模块信息</span>
            </div>
            <table class="gateWayInfoTable">
                <thead>
                    <tr>
                        <th style='width:20%'>处理模块名称</th>
                        <th style='width:15%'>处理模块类型</th>
                        <th style='width:15%'>状态</th>
                        <th style='width:20%'>版本新信息</th>
                        <th style='width:20%'>数据流</th>
                        <th style='width:10%'>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item,index) in agentApplist">
                        <td>{{ item.app_name }}</td>
                        <td>{{ item.app_type=='shadow'?'镜像':'流式' }}</td>
                        <td>{{ item.status_text }}</td>
                        <td>{{ item.app_version }}</td>
                        <td>{{ item.streaming_name==''?(item.app_type=='shadow'?'N/A':'<无>'):item.streaming_name}}</td>
                        <td><span class="btn_color" :class="{'disabled':item.classStatus}" @click="startClick(index)">{{ item.status_button }}</span>&nbsp;&nbsp;|&nbsp;&nbsp;<span class="btn_color" @click="detailClick(index)">详情</span></td>
                    </tr>
                </tbody>
            </table>
            <!--数据量-->
            <div class="gateWay">
                <span class="module_title">数据量</span>
            </div>
            <table class="gateWayInfoTable">
                <thead>
                    <tr>
                        <th style='width:25%'>处理模块名称</th>
                        <th style='width:25%'>处理模块类型</th>
                        <th style='width:25%'>接收量</th>
                        <th style='width:25%'>发送量</th>
                    </tr>
                </thead>
                <tr v-for="(item,index) in dataList">
                    <td>{{ item.app_name }}</td>
                    <td>{{item.app_type=='shadow'?'镜像':'流式'}}</td>
                    <td>{{ item.received }}</td>
                    <td>{{ item.transmitted }}</td>
                </tr>
            </table>
            <!--软件更新历史-->
            <div class="gateWay">
                <span class="module_title">软件更新历史</span>
            </div>
            <table class="gateWayInfoTable">
                <thead>
                    <tr>
                        <th style='width:25%'>处理模块名称</th>
                        <th style='width:25%'>处理模块类型</th>
                        <th style='width:25%'>更新时间</th>
                        <th style='width:25%'>版本</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(appHistory,index) in appHistoryList">
                        <td>{{ appHistory.appname }}</td>
                        <td>{{ appHistory.apptype=='shadow'?'镜像':'流式'}}</td>
                        <td>{{ appHistory.createtimeatshow }}</td>
                        <td>{{ appHistory.appversion }}</td>
                    </tr>
                </tbody>
            </table>
            <!--状态历史-->
            <div class="gateWay">
                <span class="module_title">状态历史</span>
            </div>
            <table class="gateWayInfoTable">
                <thead>
                    <tr>
                        <th style='width:25%'>网关接入名称</th>
                        <th style='width:25%'>IP地址</th>
                        <th style='width:25%'>时间</th>
                        <th style='width:25%'>状态</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(edgeHistory,index) in edgeHistoryList">
                        <td>{{ edgeHistory.username }}</td>
                        <td>{{ edgeHistory.ip }}</td>
                        <td>{{ edgeHistory.create_stamp }}</td>
                        <td>{{ edgeHistory.is_online ? '在线':'离线' }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class='btn_div'>
            <router-link to="/edge/manager" class='btn_back'>返回</router-link>
        </div>
        <div v-if= "gateWayisShow" class="dialogTask">
            <div class="catlog"><h3>网关秘钥</h3><span class="cancel_btn" @click="gateway_close">×</span></div>
            <div class="keyContent">{{this.deviceDetail.secret_key}}</div>
            <div class="btn_div_dialog">
                <span class="btn_save" @click="gateway_update">更新</span>
                <span class="btn_back" @click="gateway_close">关闭</span>
            </div>
        </div>
        <div v-if= "dialogShow" class="dialogTask handle_dialogTask">
                <div class="catlog"><h3>详情</h3><span class="cancel_btn" @click="cancleClick">×</span></div>
                <ul>
                    <li>
                        <label>处理模块名称：</label><span>{{agentApplist[dialogIndex].app_name}}</span>
                    </li>
                    <li>
                        <label>处理模块类型：</label><span>{{agentApplist[dialogIndex].app_type=='shadow'?'镜像':'流式'}}</span>
                    </li>
                    <li>
                        <label>状态：</label><span>{{agentApplist[dialogIndex].status_text}}</span>
                        <label class="label_l">版本信息：</label><span>{{agentApplist[dialogIndex].app_version}}</span>
                    </li>
                    <li>
                        <label>处理模块描述：</label><span>{{agentApplist[dialogIndex].desc}}</span>
                    </li>
                    <li>
                        <label>数据源：</label>
                        <span class = 'dialog_table'>
                            <table class="dialog_list">
                                <thead>
                                <tr>
                                    <th>数据源名称</th>
                                    <th>显示名称</th>
                                    <th>默认值</th>
                                    <th>类型</th>
                                    <th>单位</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr v-for="(item,index) in agentApplist[dialogIndex].attributes">
                                    <td>{{ item.name }}</td>
                                    <td>{{ item.desc }}</td>
                                    <td>{{ item.sourcedefault }}</td>
                                    <td>{{ item.type }}</td>
                                    <td>{{ item.unit }}</td>
                                </tr>
                                </tbody>
                            </table>
                        </span>
                    </li>
                </ul>
                <div class='btn_div_dialog'>
                    <a href='javascript:;' class='btn_back' @click="cancleClick">关闭</a>
                </div>
            </div>       
    </div>
</template>
<script>
    export default {
        created:function () {
            this.$nextTick(() => {
                this.processListFn();
            });
            // 软件更新历史
            this.$axios.post(this.$API.edgeManage.detailSoftUpdate,{'device_id': this.$route.query.deviceid}).then((res)=>{
                if(res.data.code == 420){
                    this.$router.push({path: '/login'});
                }
                this.appHistoryList = res.data.actionResult;
            });
            //数据量
            this.$axios.get(this.$API.edgeManage.detailData+"?device_id="+this.$route.query.deviceid).then((res)=>{
                if(res.data.code == 420){
                    this.$router.push({path: '/login'});
                }
               this.dataList = res.data;
            });


            //状态历史
            this.$axios.get(this.$API.edgeManage.detailStatusHistory+"?device_id="+this.$route.query.deviceid).then((res)=>{
                if(res.data.code == 420){
                    this.$router.push({path: '/login'});
                }
               this.edgeHistoryList=res.data.rows;
            });
        },
        name: 'detail',
        data () {
            return {
                gateWayisShow:false,
                dialogShow:false,
                edgeHistoryList:[],
                appHistoryList:[],
                agentApplist:[],
                dataList:[],
                dialogIndex:0,
                deviceDetail:{
                    meta:{
                        'app_key':'',
                        'console_url':'',
                        'customer_id':'',
                        'edgent_agent_app_list':'',
                        'edgent_agent_version':'',
                        'firmware_version':'',
                        'hardware_device_id':'',
                        'hardware_location':'',
                        'hardware_manufactor':'',
                        'hardware_model':'',
                        'hardware_os':'',
                        'hardware_os_version':'',
                        'hardwaredeviceid':'',
                        'hardwaremanufactor':'',
                        'hardwaremodel':'',
                        'hardwareos':'',
                        'hardwareosversion':'',
                        'id':'',
                        'json_version':'',
                        'timestampat':'',
                    }
                },
                keyStatus:false
            }
        },
        methods:{
            startClick:function (index) {
                let old_status = this.agentApplist[index].is_running;
                let device_id = this.$route.query.deviceid;
                let app_name = this.agentApplist[index].app_name;
                let handle_status='';
                if(old_status == true){
                    handle_status = 'false';
                }else{
                    handle_status = 'true';
                }
                this.$axios.post(this.$API.edgeManage.detailRun,{'device_id':device_id,'app_name':app_name,'status':handle_status}).then((res)=>{
                    // if(res.data.result == true && old_status == true){
                    //     this.agentApplist[index].status_button = '启动';
                    //     this.agentApplist[index].is_running = false;
                    //     this.agentApplist[index].status_text = '已暂停';

                    // }else if(res.data.result == true && old_status == false){
                    //     this.agentApplist[index].status_button = '暂停';
                    //     this.agentApplist[index].is_running = true;
                    //     this.agentApplist[index].status_text = '运行中';         
                    // }else{
                    //     alert('操作失败');
                    // }
                    if(res.data.code == 420){
                        this.$router.push({path: '/login'});
                    }
                    if(res.data.result == true){
                        this.agentApplist[index].classStatus = true;
                        this.agentApplist[index].status_button = '等待';
                        this.agentApplist[index].status_text = '下发中';
                        let time_list = setTimeout(()=>{
                            this.processListFn();
                        },5000);
                    }else{
                        this.$message.error('操作失败！');
                    }
                });
            },
            detailInfo:function (index) {
                
            },
            gateway_show:function(){
                this.gateWayisShow = true;
            },
            gateway_close:function(){
                this.gateWayisShow = !this.gateWayisShow;
            },
            gateway_update:function(){
                let device_id = this.deviceDetail.device_id;
                let secret = this.deviceDetail.secret_key;
                if(this.keyStatus == true){
                    return;
                }
                this.keyStatus = true;
                this.$axios.post(this.$API.edgeManage.detailKeyUpdate,{
                    'device_id':device_id,
                    'secret':secret
                }).then((res)=>{
                    if(res.data.code == 420){
                        this.$router.push({path: '/login'});
                    }
                    this.deviceDetail.secret_key = res.data.error;
                    this.keyStatus = false;
                })
            },
            processListFn(){
                //处理模块信息
                this.$axios.get(this.$API.edgeManage.detailProcess + "?device_id=" + this.$route.query.deviceid).then((res)=>{
                    if(res.data.code == 420){
                        this.$router.push({path: '/login'});
                    }
                    let obj = res.data;
                    this.deviceDetail = obj;
                    let agentArray = JSON.parse(this.deviceDetail.meta.edgent_agent_app_list);
                    for (var i = 0; i<agentArray.length; i++) {
                        if(agentArray[i].is_running == true){
                            agentArray[i].classStatus = false;
                            agentArray[i].status_text = '运行中';
                            agentArray[i].status_button = '暂停';
                        }else if(agentArray[i].is_running == false){
                            agentArray[i].classStatus = false;
                            agentArray[i].status_text = '已暂停';
                            agentArray[i].status_button = '启动';
                        }else{
                            agentArray[i].classStatus = true;
                            agentArray[i].status_text = '等待';
                            agentArray[i].pipestatus_text = '下发中';
                        }
                    }
                    this.agentApplist = agentArray;
                },function(res){
                    console.log(res)
                });
            },
            // detailClick:function (index) {
            //     this.$axios.post(this.$API.edgeManage.detailProcessDialog,{
            //         deviceidcode:this.$route.query.deviceid,
            //         appid:this.agentApplist[index].appid
            //     }).then((res)=>{
            //        console.log(res);
            //     })
            //     this.dialogShow = true;
            // },
            detailClick:function (index) {
                this.dialogIndex = index;
                this.dialogShow = true;

            },
            cancleClick:function(){
                this.dialogShow = false;
            }
        }
    }
</script>

<style>
    .gateWayInfo {
        position: relative;
        left: 20px;
        bottom:5px;
    }
    .gateWayFlag {
        position: relative;
        left: 20px;
    }
    .gateWayKey {
        float:right;
        margin-right:20px;
    }
    .gateWayInfoTable {
        position: relative;
        margin: 20px 0;
        left: 10%;
        width: 80%;
        text-align: center;
        border-collapse: collapse;
    }
   .gateWayInfoTable thead{
        height:40px;
        background:#efefef;
    }
    .gateWayInfoTable th,.gateWayInfoTable td{
      border:1px solid #eee;
    }
    .gateWayDes {
        position: relative;
        margin: 10px 0;
        left: 10%;
        width: 80%;
        font: 14px/14px 'Microsoft YaHei';
    }
    .keyContent{
        height:100px;
        line-height:100px;
        text-align:center;
    }
</style>
