<template>
    <div>
        <div class="page_title_content">
          <span class="page_title">边缘分析&nbsp;&gt;&nbsp;<router-link to="/edge/processModule" class="btn_color">处理模块管理</router-link>&nbsp;&gt;&nbsp;升级</span>
        </div>
        <div class="right_content">
            <span class="module_title">网关设备列表</span>
            <div class="list_div">
                <table class="list">
                    <thead>
                        <tr>
                            <th style='width:5%'><input type="checkbox" v-model='select_all.state'  @click="changeAllDevice" class="checkall">全选</th>
                            <th style='width:25%'>设备名称</th>
                            <th style='width:25%'>设备ID</th>
                            <th style='width:25%'>设备描述</th>
                            <th style='width:20%'>版本号</th>
                        </tr>
                    </thead>
                    <tbody>
                    <tr v-for="(task,index) in deviceInfo">
                        <td><input type="checkbox" v-model='task.state' @click="deviceCheck(index)"></td>
                        <td>{{ task.access_key }}</td>
                        <td>{{ task.device_id }}</td>
                        <td>{{ task.device_desc }}</td>
                        <td>{{ task.edgent_version }}</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class='btn_div'>
            <router-link to="/edge/processModule" class='btn_back'>返回</router-link>
            <a href='javascript:;' class='btn_save' @click="saveClick">下发</a>
        </div>
    </div>
</template>
<script>
    export default {
        created:function(){
            this.$nextTick(() => {
                this.listFn();
            });   
        },
        name: 'upgradeModule',
        data () {
            return{
                deviceInfo:[],
                select_all:{//全选按钮
                    state:false,
                    checkone_num:0,
                    all_num:0
                },
                
            }
        },
        methods: {
            listFn:function(){
                this.$axios.get(this.$API.processManage.upgradeList).then( (res) =>{
                    if(res.data.code == 420){
                        this.$router.push({path: '/login'});
                    }
                    this.deviceInfo = res.data.rows;
                    for(let i=0;i<this.deviceInfo.length;i++) {
                        this.deviceInfo[i].state = false;
                    }
                    this.select_all.all_num = this.deviceInfo.length;
                },function(res){
                  console.log(res)
                });
            },
            //全选
            changeAllDevice:function(){
                this.select_all.state = !this.select_all.state;
                if(this.select_all.state == true){
                    if(this.select_all.all_num == 0){
                        this.select_all.state == false;
                        return;
                    }
                    for (let i = 0; i<this.deviceInfo.length; i++) {
                        this.deviceInfo[i].state = true;
                    }
                    this.select_all.checkone_num = this.deviceInfo.length;
                }else{
                    for (let i = 0; i<this.deviceInfo.length; i++) {
                        this.deviceInfo[i].state = false;
                    }
                    this.select_all.checkone_num = 0;
                }
            },
            //选框
            deviceCheck:function(index){
                this.deviceInfo[index].state = !this.deviceInfo[index].state;
                if(this.deviceInfo[index].state == true){
                    this.select_all.checkone_num++;
                    if(this.select_all.all_num == this.select_all.checkone_num){
                       this.select_all.state = true;     
                    }
                }else{
                    this.select_all.checkone_num--;
                    this.select_all.state = false;
                }
            },
            //下发
            saveClick:function(){
                let deviceArr = [];
                for (let i = 0; i<this.deviceInfo.length; i++) {
                    if(this.deviceInfo[i].state == true){
                        deviceArr.push(this.deviceInfo[i].device_id);
                    }
                }
                if(deviceArr.length == 0){
                    this.$message.info('请选择设备。');
                    return;
                }
                this.$axios.post(this.$API.processManage.upgradeSave,{
                    'appid': this.$route.query.appid,
                    'deviceidArray':deviceArr
                }).then( (res) =>{
                    if(res.data.code == 420){
                        this.$router.push({path: '/login'});
                    }
                    if(res.data.actionFlag == true){
                        this.$message.success('下发成功!');
                    }
                },function(res){
                    console.log(res)
                });
            }
        }
    }
</script>