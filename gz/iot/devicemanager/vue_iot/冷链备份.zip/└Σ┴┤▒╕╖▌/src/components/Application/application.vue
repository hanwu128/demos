<template>
    <div>
       application
    </div>
</template>
<script>
    export default {
        name: 'application',
        data () {
            return {

            }
        },
    }
</script>

<style>
</style>
