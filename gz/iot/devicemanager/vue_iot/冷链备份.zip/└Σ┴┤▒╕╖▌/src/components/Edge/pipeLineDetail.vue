<template>
  <div>
    <div class="page_title_content">
      <span class="page_title">边缘分析&nbsp;&gt;&nbsp;<router-link to="/edge/pipeLine" class="btn_color">数据流管理</router-link>&nbsp;&gt;&nbsp;详情</span>
    </div>
    <div class="right_content">
       <!--基本信息-->
       <div class="line_infor">
       		<span class="module_title">基本信息</span>
       		<ul class="detail_basicmsg">
       			<li><label>数据流名称：</label><span>{{this.deviceDetail.streamingname}}</span></li>
       			<li><label>数据流描述：</label><span>{{this.deviceDetail.streamingdesc}}</span></li>
            <li><label>创建时间：</label><span>{{this.deviceDetail.createtimeatshow}}</span></li>
            <li><label>数据流状态：</label><span>{{this.deviceDetail.status ? '运行中':'已暂停'}}</span></li>
            <li><label>数据发送量：</label><span>{{this.dataNum}}</span></li>
       			<li><label>网关设备ID：</label><span>{{this.deviceDetail.deviceidcode}}</span></li>
       		</ul>
       </div>
       <!--处理模块信息-->
       <div class="line_infor">
          <span class="module_title">处理模块信息</span>
          <ul class="detail_basicmsg">
            <li><label>处理模块名称：</label><span>{{this.deviceDetail.appname}}</span></li>
            <li><label>处理模块描述：</label><span>{{this.deviceDetail.appdesc}}</span></li>
            <li><label>处理模块版本：</label><span>{{this.deviceDetail.appversion}}</span></li>
          </ul>
       </div>
       <!--MAP-->
       <div class="line_infor">
          <span class="module_title">MAP信息</span>
          <div class="pipe_line_detail_list">
         		<table class="list">
  	             <thead>
  		            <tr>
  		                <th>属性名称</th>
  		                <th>显示名称</th>
  		                <th>类型</th>
  		                <th>单位</th>
  		                <th>MAP名称</th>
  		            </tr>
  		         </thead>
  	            <tbody>
  		            <tr v-for="(MAP,index) in MAPGateWay">
  		                <td>{{MAP.sourcename}}</td>
  		                <td>{{MAP.mapnameshow}}</td>
  		                <td>{{MAP.sourcedatatype}}</td>
  		                <td>{{MAP.sourceunit}}</td>
  		                <td>{{MAP.mapname}}</td>
  		            </tr>
  	            </tbody>
  	        </table>
          </div>
       </div>
          <!--MAP-->
       <div class="line_infor">
          <span class="module_title">filter列表</span>
          <div class="pipe_line_detail_list">
         		<table class="list">
  	             <thead>
  		            <tr>
  		                <th>属性</th>
  		                <th>条件</th>
  		                <th>规则</th>
  		                <th>关联</th>
  		            </tr>
  		         </thead>
  	            <tbody>
  		            <tr v-for="(ruler,index) in rulerGateWay">
  		                <td>{{ruler.attributename}}</td>
  		                <td>{{ruler.mathematicalsymbol}}</td>
  		                <td>{{ruler.rightvalue}}</td>
  		                <td>{{ruler.logicalsymbol}}</td>
  		            </tr>
  	            </tbody>
  	        </table>
          </div>
        </div>
    </div>
    <div class='btn_div'>
      <router-link to="/edge/pipeLine" class='btn_back'>返回</router-link>
    </div>
  </div>
</template>
<script>
    export default {
        created:function () {
          let id = this.$route.query.id || '';
          let device_id = this.$route.query.deviceid || '';
          let app_name = this.$route.query.appname || '';
          this.$axios.post(this.$API.pipeLineManage.pipeLineDetail,{
              'id':id
          }).then( (res)=> {
            if(res.data.code == 420){
              this.$router.push({path: '/login'});
            }
            this.deviceDetail = res.data.streaming;
            this.MAPGateWay =  res.data.map;
            this.rulerGateWay = res.data.ruler[0]
          });
          //数据发送量
          this.$axios.get(this.$API.pipeLineManage.pipeLineDataNum+'?app_name='+app_name+'&device_id='+device_id).then( (res)=> {
            if(res.data.code == 420){
              this.$router.push({path: '/login'});
            }
            this.dataNum = res.data[0].transmitted;
          });
        },
        name: 'detail',
        data () {
            return {
                gateWayisShow:false,
                deviceDetail:{},
                MAPGateWay:{},
                rulerGateWay:{},
                dataNum:''
            }
        },
        methods:{
            updateInfo:function (index) {
                
            },
            detailInfo:function (index) {
                
            },
            gateWayKey:function () {
                this.gateWayisShow = !this.gateWayisShow
            }
        }
    }
</script>

<style>
	.detailBg h3{
		font-size:14px;
		padding-left:20px;
		border-left:2px solid #3000FF;
	}
	.line_infor{
		margin-bottom:20px;
	}
  .manager_title {
      cursor:pointer;
  }
  .detail_basicmsg{
    margin:0 25px;
  }
  .pipe_line_detail_list{
    margin:0 20px;
  }
</style>
