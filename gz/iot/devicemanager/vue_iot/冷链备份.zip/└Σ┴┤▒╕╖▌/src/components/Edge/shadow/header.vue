<template>
    <div class="page_title_content">
        <span class="page_title">边缘分析&nbsp;&gt;&nbsp;<router-link to="/edge/shadowManager" class="btn_color">设备镜像管理</router-link>&nbsp;&gt;&nbsp;创建设备镜像</span>
    </div>
</template>
<script>
    export default {
        name: 'infoHeader'
    }
</script>
<style scoped>
    .infonav{
        text-align:center;
        margin:0 20px 20px 20px;
    }
</style>