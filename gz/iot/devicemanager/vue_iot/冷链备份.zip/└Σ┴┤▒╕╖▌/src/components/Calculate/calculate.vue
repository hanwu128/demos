<template>
    <div>
        calculate
    </div>
</template>
<script>
    export default {
        name: 'calculate',
        data () {
            return {

            }
        },
    }
</script>

<style>
</style>