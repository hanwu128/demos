<template>
    <div>
        listening
    </div>
</template>
<script>
    export default {
        name: 'listening',
        data () {
            return {

            }
        },
    }
</script>

<style>
</style>