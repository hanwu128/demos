<template>
    <div>
        device
    </div>
</template>
<script>
    export default {
        name: 'device',
        data () {
            return {

            }
        },
    }
</script>

<style>
</style>