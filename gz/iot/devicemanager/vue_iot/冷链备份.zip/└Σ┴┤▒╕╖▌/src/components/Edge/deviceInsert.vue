<template>
  <div>
    <div class="page_title_content">
      <span class="page_title">边缘分析&nbsp;&gt;&nbsp;<router-link to="/edge/manager" class="btn_color">网关设备管理</router-link>&nbsp;&gt;&nbsp;创建网关设备</span>
    </div>
    <div class="right_content">
      <span class="module_title">创建网关设备</span>
      <ul class="label_ul">
        <li>
          <label class="label_title">添加方式：</label>
          <span class="tl">
            <span class="label_title"><input type="radio" name="addType" checked="checked">手动添加</span>
            <span class="label_title"><input type="radio"name="addType" >批量导入</span>
          </span>
        </li>
        <li>
          <label class="label_title">网关设备名称：</label><span><input type="text" placeholder="请输入网关设备名称" class="inputText" v-model="accesskey" minlength="4" maxlength="18"><b>*</b></span>
          <p class='tip_text'>{{accesskey_tip}}</p>
        </li>
        <!-- <li>
          <label class="label_title">网关设备ID：</label><span><input type="text" placeholder="请输入网关设备ID" class="inputText" v-model="deviceid" maxlength="40"><b>*</b></span>
          <p class='tip_text'>{{deviceid_tip}}</p>
        </li> -->
        <li>
          <label style='vertical-align: top;'class="label_title">网关设备描述：</label><span><textarea class="textarea" placeholder="请输入网关设备描述" maxlength="100" v-model="desc"></textarea></span>
        </li>
      </ul>
    </div>
    <div class="btn_div">
      <router-link to="/edge/manager" class="btn_back">取消</router-link>
      <span class="btn_save" @click="save">创建</span>
    </div>
  </div>
</template>
<script>
  export default {
    name: 'insert',
    data () {
      return {
        accesskey:'',
        deviceid:'',
        desc:'',
        focusDevice:[false,false],
        accesskey_tip:'',
        deviceid_tip:''
      }
    },
    methods: {
      save: function () {
        let reg_check = /^[\w\u4e00-\u9fa5]{4,18}$/;
        let reg_imei=/^[\u4e00-\u9fa5\\\%\&\@]{1,}$/;
        if (!reg_check.test(this.accesskey)){
          this.accesskey_tip = '请输入4-18位网关设备名称。';
          this.deviceid_tip = '';
           return;
        }
        this.$axios.post(this.$API.edgeManage.deviceAdd,{
          'access_key':this.accesskey,
          'device_desc':this.desc
        }).then( (res)=> {
          if(res.data.code == 420){
            this.$router.push({path: '/login'});
          }
          let obj = res.data;
          if(obj.result == true){
            this.$message.success('创建成功！');
            this.$router.push({path: '/edge/manager'});
          }else if(res.data.error == '103'){
            this.$message.error('创建失败！网关设备名称已存在。');
          }else {
            this.$message.error('创建失败！');
          }
        }, function (res) {
          let obj = res.data;
          this.$message.error('请求失败');
        });
      }
    }
  }
</script>