<template>
</template>
<script>
    export default {
        name: 'blank',
        data () {
            this.$router.replace('/edge/pipeLineCreate');
            return {
            }
        }
    }
</script>

<style>
</style>