<template>
  <div>
    <div class="page_title_content">
      <span class="page_title">边缘分析&nbsp;&gt;&nbsp;<router-link to="/edge/processModule" class="btn_color">处理模块管理</router-link>&nbsp;&gt;&nbsp;创建处理模块</span>
    </div>
    <div class="right_content">
        <span class="module_title">创建处理模块</span>
        <form method='get'>
          <ul class="gatewayModule">
<!--             <li>
                <label>网关设备ID：</label><span><input type='text' placeholder="请输入网关设备ID" v-model='device_id'></span>
            </li> -->
            <li>
                <label>上传处理模块：</label><span><a href="javascript:;" class="file_prev" style="position:relative;z-index:10;">本地上传</a><input type="file" id="preFile" name="staffFile"@change="ischangeFn($event)"></span>
            </li>
            <li>
                <label>处理模块：</label>
            </li>
        </ul>
      </form>
      <div class='handleList'>
        <table class="list">
          <thead>
            <tr>
              <th style='width:25%'>处理模块名称</th>
              <th style='width:25%'>处理模块类型</th>
              <th style='width:25%'>版本号</th>
              <th style='width:25%'>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-if = 'showTr'>
                <td>{{ handleItems.app.appname }}</td>
                <td>{{ handleItems.app.apptype }}</td>
                <td>{{ handleItems.app.appversion }}</td>
                <td :class="'text-center'"><span class="btn_color" @click="detailClick">详情</span></td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-if= "dialogShow" class="dialogTask handleCreateDialogTask">
          <div class="catlog"><h3 class="customer_title">详情</h3><span class="cancel_btn" @click="cancleDetailClick">×</span></div>
          <ul>
              <li>
                  <label>处理模块：</label><span>{{ handleItems.app.appname }}</span>
              </li>
              <li>
                  <label>处理模块描述：</label><span></span>
              </li>
              <li>
                  <label>属性：</label>
                  <span class = 'dialog_table'>
                      <table class="dialog_list">
                          <thead>
                          <tr>
                              <th>属性名称</th>
                              <th>显示名称</th>
                              <th>默认值</th>
                              <th>类型</th>
                              <th>单位</th>
                          </tr>
                          </thead>
                          <tbody>
                          <tr  v-for="(item,index) in handleItems.appSource">
                              <td>{{ item.sourcename }}</td>
                              <td>{{ item.sourcedisplayname }}</td>
                              <td>{{ item.sourcedefault }}</td>
                              <td>{{ item.sourcedatatype }}</td>
                              <td>{{ item.sourceunit }}</td>
                          </tr>
                          </tbody>
                      </table>
                  </span>
              </li>
          </ul>
      </div>
    </div>
    <div class='btn_div'>
        <a href='javascript:;' class='btn_back' @click="cancleClick">返回</a>
       <!--  <a href='javascript:;' class='btn_save' @click="saveClick">保存</a> -->
    </div>
  </div>
</template>
<script>
    export default {
        name: 'handleCreate',
        data () {
          return{
            createTitle:'处理模块>创建处理模块',
            device_id:'',
            dialogShow:false,
            showTr:false,
            dialogInfo:{},
            handleItems:{}
          }
        },
        methods: {
          ischangeFn(e){
            let file_self = this;
            let deviceFile = e.target.files[0];
            let formData = new FormData();
            formData.append('file', deviceFile);
            let config = {
              headers: {
                'Content-Type': 'multipart/form-data'
              }
            }
            this.$axios.post(this.$API.processManage.processAdd,
              formData, config
            ).then(function(res){
              if(res.data.code == 420){
                this.$router.push({path: '/login'});
              }
              if(res.data.actionResultFlag == false || res.data.actionResultFlag == undefined){
                if(res.data.actionResultDesc == 'md5 repeat'){
                  this.$message.error('上传失败！处理模块已存在。');
                }else{
                   this.$message.error('上传失败');
                }
                return;
              }
              file_self.handleItems=res.data;
              file_self.showTr = true;
              let obj = document.getElementById('preFile') ; 
              obj.outerHTML=obj.outerHTML;
            })
          },
          deleteClick:function (index) {
            this.$confirm('确定要删除吗？', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.handleItems = {}
              this.showTr = false;
            }).catch(() => {
               return      
            });
          },
          detailClick:function (index) {
              this.dialogShow = true;
          },
          cancleDetailClick:function(){
              this.dialogShow = false;
          },
          cancleClick:function(){
            this.$router.push({path:'/edge/processModule'});
          }
          // saveClick:function(){
          //   let appid = this.handleItems.app.id;
          //   let deviceid = this.device_id;
          //   let tasktype = this.handleItems.app.apptype;
          //   let createtimeat = this.handleItems.app.createtimeat;
          //   let commonJsonstr = this.handleItems;
          //   if(this.device_id == ''){
          //     alert('请输入网关设备ID');
          //     return;
          //   }else if(!this.handleItems.app){
          //     alert('请上传Agent');
          //     return;
          //   }
          //   this.$axios.post("http://223.203.218.93/devicemanager/TaskController/createTaskAndFire.do",
          //     {"appid": appid,"appstatus": "","createtimeat": createtimeat,"devicestatus": "","fire": true,"jarappmdfive": "","taskcode": "","taskdeploypolicyexpression": "","taskownerid": "","updatetimeat": '',"tasktype":"","commonJsonstr":commonJsonstr}
          //   ).then((res)=>{
          //     alert('保存成功');
          //     this.device_id = '';
          //     this.showTr = false;
          //   })
          // }
        }
    }
</script>
<style scoped>
    .handle_create_title {
       cursor:pointer;
    }
    .header {
        position: relative;
        top: 20px;
    }
    .create {
        position: absolute;
        right: 20px;
    }
    .gateWayInfo {
      position: relative;
      left: 20px;
      bottom:5px;
    }
    .gateWayFlag {
      position: relative;
      left: 20px;
    }
    .type {
      margin-top: 30px;
      margin-left: 5%;
      width: 80%;
    }
    .gatewayModule li{
        height: 50px;
        line-height:50px;
        padding: 0 20px;
        list-style: none;
    }
    .gatewayModule label{
        display: inline-block;
        width: 120px;
        font: 14px/50px 'Microsoft YaHei';
        text-align: left;
        vertical-align: top;
    }
    .file_prev {
      display:inline-block;
      font: 14px/30px 'Microsoft YaHei';
      width:120px;
      height:30px;
      text-align:center;
      background: #388bd7;
      color: #fff;
      border-radius:4px;
    }
    #preFile{
      position: absolute;z-index:100;opacity:0;width:120px;height:30px;cursor:pointer;margin: 10px 0 0 -120px;
    }
    .handleList{
      min-height:200px;
      margin:0 20px;
    }
    .handleCreateDialogTask{
        width: 650px;
        min-height: 400px;
        margin-left: -300px;
    }
    .handleCreateDialogTask ul{
        margin:20px 0 0 0;
        padding:0;
    }
    .handleCreateDialogTask li{
        height: 50px;
        line-height:50px;
        padding: 0 20px;
        list-style: none;
    }
    .handleCreateDialogTask label{
        display: inline-block;
        width: 120px;
        font: 14px/50px 'Microsoft YaHei';
        text-align: left;
        vertical-align: top;
    }
    .handleCreateDialogTask .label_l{
        margin-left:60px;
    }
    .handleCreateDialogTask ul span{
        display:inline-block;
        min-width:120px;
    }
    .dialog_list{
        border-collapse: collapse;
        font: 14px/21px 'Microsoft YaHei';
        width: 400px;
        margin-top:5px;
        text-align: center;
    }
    .dialog_list th,.dialog_list td{
        border:1px solid #ccc;
    }
    .dialog_table{
      height:200px;
      overflow:auto;
    }
</style>