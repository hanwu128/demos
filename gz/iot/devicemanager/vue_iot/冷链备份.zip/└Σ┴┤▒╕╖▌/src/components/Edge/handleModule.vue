<template>
    <div>
        <div class="page_title_content">
          <span class="page_title">边缘分析&nbsp;&gt;&nbsp;<router-link to="/edge/processModule" class="btn_color">处理模块管理</router-link></span>
        </div>
        <div class="right_content">
            <div class="header">
                <input class="search_text" type="text" placeholder="请输入模块名称" v-model='searchTerms.appname'>
                <select class="search_select" v-model='searchTerms.apptype'>
                    <option value=''>处理模块类型</option>
                    <option value='shadow'>镜像</option>
                    <option value='stream'>流式</option>
                </select>
                <!-- <select class="search_select" v-model='searchTerms.taskstatus'>
                    <option value=''>状态选择</option>
                    <option value='successSendMqtt'>运行中</option>
                    <option value='2'>已卸载</option>
                </select> -->
                <span class='btn_save' @click="searchClick()">搜索</span>
                <span class="btn_create fr" @click="createClick()">创建处理模块</span>
            </div>
            <div class="handle_module_list">
                <table class="list">
                    <thead>
                    <tr>
                        <th style='width:5%'>编号</th>
                        <th style='width:20%'>处理模块名称</th>
                        <th style='width:17%'>类型</th>
                        <!-- <th style='width:15%'>状态</th> -->
                        <th style='width:19%'>版本号</th>
                        <th style='width:20%'>创建时间</th>
                        <th style='width:19%'>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr v-for="(task,index) in taskInfo">
                        <td>{{ index + 1 }}</td>
                        <td>{{ task.appname }}</td>
                        <td>{{ task.apptype_text }}</td>
                        <!-- <td>{{ task.appstatus_text }}</td> -->
                        <td>{{ task.appversion }}</td>
                        <td>{{ task.createtimeatshow }}</td>
                        <td :class="'text-center'"><span class="btn_color" @click="upgradeClick(index)">升级</span>&nbsp;&nbsp;|&nbsp;&nbsp;<span class="btn_color" @click="detailClick(index)">详情</span></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <!-- <div v-if= "dialogShow" class="dialogTask handle_dialogTask">
                <div class="catlog"><h3>详情</h3><span class="cancel_btn" @click="cancleClick">×</span></div>
                <ul>
                    <li>
                        <label>处理模块名称：</label><span>{{dialogInfo.app.appname}}</span>
                    </li>
                    <li>
                        <label>处理模块类型：</label><span>{{dialogInfo.app.apptype_text}}</span>
                    </li>
                    <li>
                        <label>状态：</label><span></span>
                        <label class="label_l">版本信息：</label><span>{{dialogInfo.app.appversion}}</span>
                    </li>
                    <li>
                        <label>处理模块描述：</label><span>{{dialogInfo.app.appdesc}}</span>
                    </li>
                    <li>
                        <label>数据源：</label>
                        <span class = 'dialog_table'>
                            <table class="dialog_list">
                                <thead>
                                <tr>
                                    <th>数据源名称</th>
                                    <th>显示名称</th>
                                    <th>默认值</th>
                                    <th>类型</th>
                                    <th>单位</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr v-for="(item,index) in dialogInfo.appsourcearray">
                                    <td>{{ item.sourcename }}</td>
                                    <td>{{ item.sourcedisplayname }}</td>
                                    <td>{{ item.sourcedefault }}</td>
                                    <td>{{ item.sourcedatatype }}</td>
                                    <td>{{ item.sourceunit }}</td>
                                </tr>
                                </tbody>
                            </table>
                        </span>
                    </li>
                </ul>
                <div class='btn_div_dialog'>
                    <a href='javascript:;' class='btn_back' @click="cancleClick">关闭</a>
                </div>
            </div> -->
        </div>
    </div>
</template>
<script>
    export default {
        created:function () {
            this.$nextTick(() => {
                this.listFn();
            });
        },
        name: 'taskList',
        data () {
            return{
                taskInfo:[],
                dialogInfo:{
                    app:{
                        appname:''
                    }
                },
                searchTerms:{
                    'appname':'',
                    'apptype':'',
                    'taskstatus':''
                },
                dialogShow:false,
                value: 0
            }
        },
        methods: {
            listFn:function(){
                this.$axios.post(this.$API.processManage.processList,this.searchTerms).then( (res)=>{
                    if(res.data.code == 420){
                        this.$router.push({path: '/login'});
                    }
                    let arrTask = res.data.actionResult;
                    this.taskInfo = [];
                    for(var i=0;i<arrTask.length;i++) {
                        if(arrTask[i].appstatus == 'true'){
                            arrTask[i].status_text = '暂停';
                            arrTask[i].appstatus_text = '运行中';
                        }else{
                            arrTask[i].status_text = '启动';
                            arrTask[i].appstatus_text = '已暂停';         
                        }
                        if(arrTask[i].apptype == 'stream'){
                            arrTask[i].apptype_text = '流式';
                        }else{
                            arrTask[i].apptype_text = '镜像';
                        }
                        this.taskInfo.push(arrTask[i]);
                    }
                });

            },
            createClick:function () {
                this.$router.push({path:'/edge/handleCreate'});
            },
            selectFn: function(value){
                console.log(value);
            },
            // handleClick:function (index) {
            //     let old_status = this.taskInfo[index].appstatus;
            //     let device_id = this.taskInfo[index].deviceid;
            //     let app_name = this.taskInfo[index].appname;
            //     let handle_status='';
            //     if(old_status == 'true'){
            //         handle_status = 'false';
            //     }else{
            //         handle_status = 'true';
            //     }
            //     this.$axios.post("http://223.203.218.93/devicemanager/TaskController/run_app.do",{'device_id':device_id,'app_name':app_name,'status':handle_status}).then( (res)=>{
            //         if(res.data.result == true && old_status == 'true'){
            //             this.taskInfo[index].status_text = '启动';
            //             this.taskInfo[index].appstatus = 'false';
            //             this.taskInfo[index].appstatus_text = '已暂停';

            //         }else if(res.data.result == true && old_status == 'false'){
            //             this.taskInfo[index].status_text = '暂停';
            //             this.taskInfo[index].appstatus = 'true';
            //             this.taskInfo[index].appstatus_text = '运行中';         
            //         }else{
            //             alert('操作失败');
            //         }
            //     });
            // },
            detailClick:function (index) {
                let dialog_id = this.taskInfo[index].id;
                this.$router.push({path:'/edge/processDetail',query: { id:dialog_id}});
                // this.dialogShow = true;
                // this.$emit("backgroundFn",true);
                // this.$axios.post(this.$API.pipeLineManage.createDescApp,{
                //     'id':dialog_id,
                //     'appid':dialog_appid
                // }).then( (res)=>{
                //     let arrDialog = res.data.actionResult;
                //     if(arrDialog.app.apptype == 'stream'){
                //         arrDialog.app.apptype_text = '流式';
                //     }else{
                //         arrDialog.app.apptype_text = '镜像';
                //     }
                //     this.dialogInfo = arrDialog;
                // })
            },
            cancleClick:function(){
                this.dialogShow = false;
            },
            searchClick:function(){
                this.listFn();
            },
            //升级
            upgradeClick:function(index){
                this.$router.push({path:'/edge/upgradeModule',query: { appid: this.taskInfo[index].id}})
            }
        }
    }
</script>

<style scoped>
    .header,.handle_module_list {
        margin:0 20px 20px 20px;
    }
</style>