<template>
    <div>
    	<header-viewers></header-viewers>
        <div  class="right_content tc">
            <img src="../../../assets/images/shadowStep1.png">
        </div>
        <div  class="right_content shadow_first_step">
            <ul class="shadowManagerUl label_ul">
                <li>
                    <label class="label_title">设备镜像名称：</label><span><input placeholder='请输入设备镜像名称' v-model="shadowName" class='inputText'><b>*</b></span>
                    <p class='tip_text'>{{shadowname_tip}}</p>
                </li>
                <li>
                    <label style='vertical-align: top;' class="label_title">设备镜像描述：</label><span><textarea placeholder="请输入字符描述" maxlength="100" v-model="shadowDesc"></textarea></span>
                </li>
                <li>
                    <label class="label_title">网关设备ID：</label><span>
                        <select v-model='deviceID' class='select_style'>
                            <option v-for="(item,index) in deviceid_list" :value="item.device_id">{{ item.access_key }}</option>
                        </select>
                    </span>
                </li>
            </ul>
        </div>
        <div class="btn_div_right">
            <span class="btn_back" @click="cancle">取消</span>
            <span class="btn_save" @click="next">下一步</span>
        </div>
    </div>
</template>
<script>
	import headerViewers from './header.vue'
    export default {
        name: 'insertInfo',
        data () {
            return {
                shadowName:'',
                shadowDesc:'',
                deviceID:'',
                deviceid_list:{},
                shadowname_tip:''
            }
        },
        components: {
      		headerViewers : headerViewers
    	},
        methods:{
            cancle:function () {
                this.$router.push({path:'/edge/shadowManager'})

            },
            next:function () {
            	let name = this.$data.shadowName;
            	let desc = this.$data.shadowDesc;
            	let id = this.$data.deviceID
                let reg_check = /^[\w\u4e00-\u9fa5]{4,18}$/;
                if(!reg_check.test(name)){
                    this.shadowname_tip='请输入4-18位设备镜像名称';
                    return
                }
                this.$router.push({path:'/edge/shadow/module',query:{shadowName:this.shadowName,shadowDesc:this.shadowDesc,deviceID:this.deviceID}})
            }
        },
        created:function () {
            this.$axios.post(this.$API.pipeLineManage.createDeviceId,{
            }).then( (res)=>{
                if(res.data.code == 420){
                    this.$router.push({path: '/login'});
                }
                this.deviceid_list = res.data.rows;
                this.deviceID = res.data.rows[0].device_id;
            });
        }
    }
</script>

<style>
    .account {
        margin-top: 20px;
        margin-left: 5%;
    }
    .cancle {
        width: 80px;
        height: 30px;
        border: groove 1px solid;
        background-color: deepskyblue;
        position: relative;
        top: 50px;;
        left: 40%;
        cursor: pointer;
        outline: none;
    }

    .shadowdescribe {
        position: relative;
        bottom: 190px;
    }
    .shadow_first_step{text-align:center;margin-top:40px;}
    .shadow_first_step label{
        display: inline-block;
        width: 100px;
        margin-right:10px;
        font: 14px/14px 'Microsoft YaHei';
        text-align: right;
    } 
    .shadow_first_step li{height:50px;margin-top:10px;}  
    .shadow_first_step input{width:396px;}
    .shadow_first_step textarea{width:398px;}
    .shadow_first_step select{width:400px;}
</style>