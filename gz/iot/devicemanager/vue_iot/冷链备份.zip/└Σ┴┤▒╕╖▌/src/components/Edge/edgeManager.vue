<template>
  <div>
    <div class="page_title_content">
      <span class="page_title">边缘分析&nbsp;&gt;&nbsp;<router-link to="/edge/manager" class="btn_color">网关设备管理</router-link></span>
    </div>
    <div class="right_content">
      <div class="header">
        <input class="search_text" type="text" placeholder="请输入网关设备ID" v-model="search_data.device_id">
        <select class="search_select" v-model="search_data.edgent_version">
          <option value="">请选择Agent版本</option>
          <option value="0.1.0">0.1.0</option>
        </select>
        <span class='btn_save' @click="searchClick()">搜索</span>
        <span class="btn_create fr" @click="newDevice">创建网关设备</span>
        <span class="btn_create fr agaent">Agent批量更新</span>
      </div>
      <div class="edge_manager_list">
        <table class="list">
          <thead>
          <tr>
            <th style='width:5%'>编号</th>
            <th style='width:20%'>网关设备名称</th>
            <th style='width:20%'>网关设备描述</th>
            <th style='width:5%'>状态</th>
            <th style='width:15%'>Agent版本</th>
            <th style='width:20%'>创建时间</th>
            <th style='width:15%'>操作</th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="(device,index) in deviceInfo">
            <td>{{ index + 1 }}</td>
            <td>{{ device.access_key }}</td>
            <td>{{ device.device_desc }}</td>
            <td>{{ device.status == 1 ? '在线' : '离线'}}</td>
            <td>{{ device.edgent_version }}</td>
            <td>{{ device.create_stamp }}</td>
            <td :class="'text-center'"><span class="btn_color" @click="detailInfo(index)">详情</span>&nbsp;&nbsp;|&nbsp;&nbsp;<span class="btn_color"  :class="{'disabled':device.status == 1 ? true : false}"  @click="deleteInfo(index)">删除</span></td>
          </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    created:function () {
      this.$nextTick(() => {
        this.listFn();
      });
    },
    // mounted:function(){
    //   window.onpopstate = () => {
    //     window.history.pushState('forward', null, ''); 
    //     window.history.forward(1);
    //   }
    // },
    name: 'edgeManage',
    data () {
      return {
        deviceInfo: [],
        search_data:{
          device_id:"",
          edgent_version:""
        }
      }
    },
    methods: {
      listFn:function(){
        this.$axios.get(this.$API.edgeManage.deviceList+"?device_id="+this.search_data.device_id+"&edgent_version="+this.search_data.edgent_version).then( (res) =>{
          if(res.data.code == 420){
            this.$router.push({path: '/login'});
          }
          let arr = res.data.rows;
          this.deviceInfo = [];
          for(var i=0;i<arr.length;i++) {
            this.deviceInfo.push(arr[i])
          }
        },function(res){
          console.log(res)
        });
      },
      detailInfo:function (index) {
        this.$router.push({path:'/edge/detail',query: { deviceid: this.deviceInfo[index].device_id}});
      },
      deleteInfo:function (index) {
        if(this.deviceInfo[index].status == 1){
          return
        }
        this.$confirm('确定要删除设备“'+ this.deviceInfo[index].device_id +'”吗？删除后设备将无法接入系统。', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$axios.post(this.$API.edgeManage.deviceDelete,{
            'device_id':this.deviceInfo[index].device_id
          }).then((res)=>{
            if(res.data.code == 420){
              this.$router.push({path: '/login'});
            }
            let obj = res.data;
            if(obj.result == true) {
              this.deviceInfo.splice(index,1);
            }else {
              this.$message.error('删除失败!');
            }
          },function(res){
            console.log(res)
          });
        }).catch(() => {
           return      
        });
      },
      newDevice:function () {
        this.$router.push({path:'/edge/insert'})
      },
      searchClick:function(){
        this.listFn();
      }
    }
  }
</script>
<style scoped>
  .edge_manager_list {
    margin:0 20px 20px 20px;
  }
  .searchSelect {
    margin-left:20px;
  }
  .agaent {
    margin-right:20px;
  }
</style>
