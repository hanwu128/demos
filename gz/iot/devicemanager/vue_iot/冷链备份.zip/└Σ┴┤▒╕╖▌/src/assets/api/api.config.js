/**********************
* 统一存储接口,使用模块名+接口名
* @version v1.0.0
* @author:Mad
* @QQ:1823737636
* @date:2017-9-21
* @edit:2017-11-8
**********************/
const DEBUG = true
let BASE_URL = DEBUG ? 'http://223.203.218.93' : '';//产线环境
//let BASE_URL = DEBUG ? 'http://172.17.199.109:8080' : '';//测试环境
//let BASE_URL = DEBUG ? 'http://10.100.157.34:8081' : '';//本地环境
//let LOGIN_URL = DEBUG ? 'http://10.100.156.81:8080' : '';
const API = {
    //登录
    'login':{
        'imgCode':BASE_URL + '/devicemanager/authcode/image.url',//验证码
        'accountLogin' : BASE_URL + '/devicemanager/account/login.do',//登录接口
        'logOut': BASE_URL + '/devicemanager/account/logout.do'//登出接口
    },
    //信息管理
    'infoManage':{
        'personalData':BASE_URL + '/devicemanager/account/meta.do',//查看个人资料，get请求
        'editPersonalData' : BASE_URL + '/devicemanager/account/metasetting.do',//编辑个人资料，post请求
        'getCode': BASE_URL + '/devicemanager/authcode/code.do',//获取邮箱验证码，get请求
        'resetCheckPwd': BASE_URL + '/devicemanager/account/resetpassword/step1.do',//验证验证码，post请求
        'resetPwd': BASE_URL + '/devicemanager/account/resetpassword/step2.do',//重置密码，post请求
        //账号管理
        'accountList': BASE_URL + '/devicemanager/account/list.do',//账号列表，get请求
        'accountEnabled': BASE_URL + '/devicemanager/account/enabled.do',//启动，暂停
        'accountDelete': BASE_URL + '/devicemanager/account/delete.do',//删除
        'accountAdd': BASE_URL + '/devicemanager/account/add.do',//添加账户
        'setPermission': BASE_URL + '/devicemanager/account/permissionsetting.do',//设置权限
        'searchPermission': BASE_URL + '/devicemanager/account/permission.do',//查询权限
        //企业信息
        'getInfo': BASE_URL + '/devicemanager/company/get.do',//查询信息
        'updateInfo': BASE_URL + '/devicemanager/company/update.do'//更新信息
    },
    //网关设备管理
    'edgeManage':{
        'deviceList':BASE_URL + '/devicemanager/device/list.do',//网关设备列表
        'deviceDelete':BASE_URL + '/devicemanager/device/delete.do',//网关设备删除
        'deviceAdd':BASE_URL + '/devicemanager/device/add.do',//创建网关设备
        'detailProcess':BASE_URL + '/devicemanager/device/get.do',//详情处理模块信息
        'detailSoftUpdate':BASE_URL + '/devicemanager/TaskController/findTasklistbyparameters.do',//详情软件更新信息
        'detailData':BASE_URL + '/devicemanager/device/get_message_statistics.do',//详情数据量
        'detailStatusHistory':BASE_URL + '/devicemanager/device/online_history.do',//详情状态历史
        'detailRun':BASE_URL + '/devicemanager/TaskController/run_app.do',//详情启动暂停
        'detailKeyUpdate':BASE_URL + '/devicemanager/device/update_secret.do',//详情更新秘钥
        'detailProcessDialog':BASE_URL + '/devicemanager/StreamingPipeLineController/findStreamingDeviceAppVOBaseById.do'//处理模块信息详情
    },
    //数据流管理
    'pipeLineManage':{
        'pipeLineList':BASE_URL + '/devicemanager/StreamingPipeLineController/findStreamingDeviceAppVOBaseByParameters.do',//数据流列表
        'pipeLineDelete':BASE_URL + '/devicemanager/StreamingPipeLineController/deleteStreaming.do',//数据流删除
        'pipeLineDetail':BASE_URL + '/devicemanager/StreamingPipeLineController/findStreamingDeviceAppVOBaseById.do',//数据流详情
        'createDeviceId':BASE_URL + '/devicemanager/device/list2.do',//数据流创建获取网关设备id
        'createFindAllTask':BASE_URL + '/devicemanager/TaskController/listapps.do',//数据流创建获取属性列表
        'createDescApp':BASE_URL + '/devicemanager/TaskController/descApp.do',//数据流创建获取处理模块
        'createPipeLine':BASE_URL + '/devicemanager/StreamingPipeLineController/nurturedStreamingPipeLine.do',//数据流创建
        'createRepeatCheck':BASE_URL + '/devicemanager/StreamingPipeLineController/findStreamingDeviceAppVOBaseByParameters.do',//数据流创建重复判断
        'pipeLineDataNum':BASE_URL + '/devicemanager/device/get_message_statistics.do',//数据发送量,get请求,参数device_id和app_name
        'pipeLineChoice':BASE_URL + '/devicemanager/device/get_applist.do'//选择处理模块,post请求,参数device_id和app_type
    },
    //设备镜像管理
    'shadowManage':{
        'shadowList':BASE_URL + '/devicemanager/deviceshadow/list.do',//设备镜像列表
        'configList':BASE_URL + '/devicemanager/deviceshadow/get.do',//设备镜像配置列表,详情
        'configSave':BASE_URL + '/devicemanager/deviceshadow/update_item_expectvalue.do',//设备镜像配置保存
        'shadowDelete':BASE_URL + '/devicemanager/deviceshadow/delete.do',//设备镜像删除
        'createDescApp':BASE_URL + '/devicemanager/TaskController/descApp.do',//设备镜像创建获取处理模块
        'createFindAllTask':BASE_URL + '/devicemanager/TaskController/findAllTaskJSONP.do',//设备镜像创建获取属性列表
        'shadowAdd':BASE_URL + '/devicemanager/deviceshadow/add.do',//设备镜像创建获取属性列表
        'shadowExist':BASE_URL + '/devicemanager/deviceshadow/exist.do'//设备镜像创建重复判断，get请求，参数：device_id,app_name

    },
    //处理模块管理
    'processManage':{
        'processList':BASE_URL + '/devicemanager/TaskController/listapps.do',//处理模块列表
        'processAdd':BASE_URL + '/devicemanager/JarController/springUpload.do',//处理模块添加
        'upgradeList':BASE_URL + '/devicemanager/device/list2.do',//处理模块升级列表
        'upgradeSave':BASE_URL + '/devicemanager/TaskController/createTaskAndFireBatch.do',//处理模块升级下发
        'processDetailList':BASE_URL + '/devicemanager/TaskController/findTasklistbyparameters.do',//处理模块列表
    },
    //标签管理
    'labelManage':{
        'labelList':BASE_URL + '/devicemanager/SensorTemperatureDayVOController/findSensorTemperatureDayVOByParameter.url',//标签列表
        'labelLine':BASE_URL + '/devicemanager/SensorTemperatureDayVOController/listSensorTemperatureHistoryBySensorstampwithInterval.url',//标签实时刷新折线图
        'labelDetailList':BASE_URL + '/devicemanager/SensorTemperatureDayVOController/descByPrimarykeyAndTimeat.url'//标签详情列表
    },
    //冷链管理
    //数据概述
    'dataOverview':{
        'overviewDeviceList':BASE_URL + '/devicemanager/stream/devicelist.url',//设备列表查询
        'mapData':BASE_URL + '/devicemanager/stream/get_gps.url',//地图接口
        'overviewNum':BASE_URL + '/devicemanager/stream/get_breif.url',//概览数据
        'overviewPie':BASE_URL + '/devicemanager/stream/get_data_proportion.url',//饼图接口
        'actualLine':BASE_URL + '/devicemanager/SensorTemperatureDayVOController/getPiechar.url',//实时数据折线图
        'trendLine':BASE_URL + '/devicemanager/stream/get_data_trend.url'//趋势折线图
    },
    //实时数据
    'realtimeData':{
        'realtimeList':BASE_URL + '/devicemanager/SensorTemperatureDayVOController/findSensorTemperatureDayVOByParameter.url',//实时数据标签列表查询
    }
}
export default API;
